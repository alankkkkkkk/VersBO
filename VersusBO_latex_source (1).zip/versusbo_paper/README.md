# VersusBO 论文工程（组会模拟版）

本工程只供组会学习模拟使用。所有实验数值都是按论文逻辑预估的投影值（projected），不是真实运行结果。

版式：ACL 官方样式（ARR 通用，NAACL 2027 与 COLING 2027 都走 ARR），`[review]` 匿名模式。正文 8 页，Limitations、Ethical Considerations、参考文献和附录都排在正文后面，不计入页数。

## 目录

| 路径 | 内容 |
|---|---|
| `acl/main.tex` | 主文件 |
| `shared/method_name.json` | **方法名只在这里设一处**；正文、表格和图都从这里读取 |
| `shared/sections/*.tex` | 正文与附录 |
| `shared/figures/fig1a_ask.tex`, `fig2_method.tex` | 图 1(a) 与图 2（方法图）的 TikZ 源码 |
| `shared/generated/` | 由脚本生成的表格、宏、方法名和数据，不要手改 |
| `scripts/make_results.py` | 全文所有数字的唯一来源（模拟 20 个种子），导出表格、`macros.tex` 和 `results.json` |
| `scripts/make_figures.py` | 数据图（字体与 ACL 正文的 Times 一致） |
| `scripts/otf2ttf.py` | 把 OTF 字体转为 TrueType，保证 PDF 里没有 Type 3 字体 |

## 编译

```bash
python3 scripts/make_results.py
python3 scripts/make_figures.py times
cd acl && latexmk -pdf main.tex
```

## 换方法名

1. 修改 `shared/method_name.json`：`display` 用于图中，`tex` 用于正文；外层的 `\mbox{}` 用来防止断词。
2. 依次运行上面的三条命令。
3. 再手动改 `acl/main.tex` 里的 `\title{...}`。
