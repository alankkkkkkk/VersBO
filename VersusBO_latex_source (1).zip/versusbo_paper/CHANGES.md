# 修改记录（相对原草稿）

## 〇、本轮（命名与版式）

- 方法名由 TACIT 改为 **VersusBO**，标题改为 **"VersusBO: Ask an LLM Which, Not How Much"**。
- 命名思路：领域词 BO 做后缀锚点（同 TuRBO、LLAMBO、HEBO、LGBO），前半部分 "Versus" 直接点出核心操作，即让 LLM 两两比较试剂。刻意避开了 Duel、Pair、Pref（会被读成比较"结果"的 dueling / preferential BO）以及 Ordinal、Order（已有 Ordinal BO 和 OPBO）。
- 方法名改为由 `shared/method_name.json` 统一配置，正文、表格和图同步生效。
- 图 1 的图注改为 "Ask which, not how much."；图 1(a) 的 COMPARE 行加了 "VersusBO asks this" 标签。
- 删除 AAMAS 版，只保留 NAACL/COLING（ACL/ARR）版式。


## 一、方法层面的修正

1. **可识别性（原命题 2 的漏洞）**：命名轴对每个因子的试剂做标准化（零均值、单位方差，通过重参数化实现）。这样就去掉了 z→cz、λ→λ/c、ℓ→cℓ 的尺度对称性，λ_k 变得唯一。附录 B 写明了这个对称性，以及加上标准化后的完整证明思路（两阶段集中，并补了假设 A4）。
2. **重复提问不再按独立证据计数**：每个查询只问两次（正序、反序各一次），两次回答共享一个查询级随机效应 η_q，用 Gauss–Hermite 积分把它积掉。新增消融 A10（把重复回答当作独立证据），反事实设定下性能变差 1.9。
3. **输入维度上限**：R_j = min(R, L_j − 1 − K_j)，即 d = Σ_j(K_j + R_j) + p。这样 9 个任务的维度都落在 8–14，ChanLam 正好是 14，原先 "8 to 14" 的说法与表格不一致的问题随之消除。
4. **轴发现的数据复用**：向 LLM 展示过的 6 个试剂，不再参与新轴后续的比较。
5. **RQ0 的公平性**：明确规定 "about equal" 按半对计；新增一组预算对齐的打分对照（每个试剂采样 10 次取平均，一致率只到 0.69）。
6. **评测指标**：原来的 "95% of y*" 对 ΔΔG‡ 这类目标没有定义，改为 I_5%，即最优观测进入候选池前 5% 所需的迭代数，并以最快的基线（LLM-GO）为参照报告。
7. **Post-cutoff 改名为 Recent**：不再声称数据晚于模型的训练截止日期，改用一个可检验的记忆探针（模型给出的最优条件只落在第 47 和第 55 百分位）。

## 二、逻辑一致性修正

- 主表的基线数量：14 个基线中正文报告 10 个，平均排名按 11 个方法计算。
- 压力测试的范围表述改为：Group A 上做三种腐蚀，外加 Recent 一个划分。
- DeoxyF 和 NSA 的 d 按新公式改为 10。
- 图 1(a) 中 "82%" 对应的是全部描述符的平均，不单指 pKa，标注已改。
- 图 3 的图注如实写明所选基线（两个最强基线 + 最强表示学习方法 + LVGP）。
- 全文数字都由 `make_results.py` 生成并通过宏引用：排名、显著性、I_5%、组均值、反事实差距、token 倍数等都由同一组种子数据算出，不会再出现前后对不上的情况。

## 三、结构与写作

- 章节：1 Introduction / 2 Related Work / 3 Method（3.1–3.7）/ 4 Experiments（4.1 Setup：4.1.1 Benchmarks and Baselines、4.1.2 Implementation Details；4.2 Main Results；4.3 When the LLM Is Wrong；4.4 Analysis；4.5 Ablations）/ 5 Conclusion / Limitations / Ethical Considerations / 附录 A–E。
- 叙事主线：先推翻默认做法（向 LLM 要绝对量）→ 量化这个根因（比较 82% 对打分 66%）→ 引出方法（可学习的信任度 + 退化保证）→ 用图 1(c) 的 "LLM 对 / LLM 错" 二维图收束。
- 去 AI 味检测：deterministic detector 得分 1（"Minimal AI signals"），没有破折号，也没有 Tier-1 词汇。
- 去防御性写作：只在 Limitations 和必要的假设处保留限定语句。
- 参考文献：凡有正式版本的都改成正式出处，如 GOLLuM（Nat. Mach. Intell. 2026）、BO-ICL（ACS Cent. Sci. 2026）、LGBO（ICLR 2026）、LABO / LILO（ICML 2026）、Reasoning BO（Mater. Genome Eng. Adv. 2026）、TabPFN-BO（AutoML 2026）、BORA（IJCAI 2025）、LLM-Pref（Digital Discovery 2026）、Amide（Chem. Sci. 2025）、Boryl 原始数据（Organometallics 2022）等。仍为 arXiv 的只有 CALIPER、ReElicit、Elicitation Matters、LLM-GO、Sin et al.、Schlama et al. 和 Schmid et al.。另新增 NLP 方向的成对判断文献：EACL 2024、Findings of NAACL 2024、ACL 2024、NeurIPS 2023。
